AI-generated illustrative Indian garage image for the Garagewala homepage. This is not a photograph of the actual Garagewala workshop or staff.
