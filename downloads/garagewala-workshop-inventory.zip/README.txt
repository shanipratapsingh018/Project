AI-generated illustrative Indian garage image showing spare parts inventory, engine servicing and suspension repair. This is not a photograph of the actual Garagewala workshop or staff.
